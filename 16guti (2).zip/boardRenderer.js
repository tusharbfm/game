const BoardRenderer = (() => {
    let containerElement;

    function getBoardDimensions() {
        const rect = containerElement.getBoundingClientRect();
        return { width: rect.width, height: rect.height };
    }

    function createLine(className, style) {
        const div = document.createElement('div');
        div.className = className;
        Object.assign(div.style, style);
        containerElement.appendChild(div);
    }

    function createPoint(id, left, top, type, label = '', isOnlineOpponentView = false) {
        const div = document.createElement('div');
        div.className = `point ${type}`;
        div.style.left = `${left}%`;
        div.style.top = `${top}%`;
        div.dataset.pointId = id;

        if (type === 'red-piece' || type === 'green-piece') {
            const piece = document.createElement('div');
            piece.className = `piece ${type.split('-')[0]}`;
            div.appendChild(piece);
        } else if (label) {
            div.textContent = label;
        }

        div.addEventListener('touchstart', (event) => {
            event.preventDefault(); // Prevent default touch behavior like scrolling or zooming
            if (typeof GameLogic !== 'undefined' && typeof GameLogic.handlePointClick === 'function') { // Changed from handlePointClick to handlePointTouch
                GameLogic.handlePointClick(div); // Changed from handlePointClick to handlePointTouch
            } else {
                console.warn('GameLogic.handlePointClick is not defined.'); // Changed from handlePointClick to handlePointTouch
            }
        });

        containerElement.appendChild(div);
        return div; // Return the created point element
    }

    function calculateDiagonal(startX, startY, endX, endY, boardWidth, boardHeight, isOnlineOpponentView) {
        let adjustedStartX = startX;
        let adjustedStartY = startY;
        let adjustedEndX = endX;
        let adjustedEndY = endY;

        if (isOnlineOpponentView) {
            adjustedStartX = 100 - startX;
            adjustedStartY = 100 - startY;
            adjustedEndX = 100 - endX;
            adjustedEndY = 100 - endY;
        }

        const x1 = (adjustedStartX / 100) * boardWidth;
        const y1 = (adjustedStartY / 100) * boardHeight;
        const x2 = (adjustedEndX / 100) * boardWidth;
        const y2 = (adjustedEndY / 100) * boardHeight;

        const lengthPx = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        const lengthPercent = (lengthPx / boardWidth) * 100;

        const angleRad = Math.atan2(y2 - y1, x2 - x1);
        const angleDeg = (angleRad * 180) / Math.PI;

        return {
            left: `${adjustedStartX}%`,
            top: `${adjustedStartY}%`,
            width: `${lengthPercent}%`,
            height: 'max(2px, 0.5vmin)',
            transform: `rotate(${angleDeg}deg)`,
            transformOrigin: isOnlineOpponentView ? '100% 50%' : '0% 50%'
        };
    }

    function setOpponentView(enabled) {
        if (!containerElement) return;
        containerElement.style.transform = enabled ? 'rotate(180deg)' : '';
        containerElement.style.transformOrigin = '50% 50%';
    }

    function drawBoard() {
        if (!containerElement) {
            console.error('Container element not set for BoardRenderer.');
            return;
        }
        containerElement.innerHTML = '';

        const { width: boardWidth, height: boardHeight } = getBoardDimensions();

        const gridX = [5, 27.5, 50, 72.5, 95];
        const gridY = [5, 16.25, 27.5, 38.75, 50, 61.25, 72.5, 83.75, 95];

        const rotateForBottomPerspective = GameLogic.currentMode === 'online' && GameLogic.localPlayerColor === 'red';
        setOpponentView(rotateForBottomPerspective);

        const horizontalLines = [
            { class: 'line h1', top: gridY[0], left: gridX[0], width: gridX[4] - gridX[0] },
            { class: 'line h2', top: gridY[1], left: gridX[1], width: gridX[3] - gridX[1] },
            { class: 'line h3', top: gridY[2], left: gridX[0], width: gridX[4] - gridX[0] },
            { class: 'line h4', top: gridY[3], left: gridX[0], width: gridX[4] - gridX[0] },
            { class: 'line h5', top: gridY[4], left: gridX[0], width: gridX[4] - gridX[0] },
            { class: 'line h6', top: gridY[5], left: gridX[0], width: gridX[4] - gridX[0] },
            { class: 'line h7', top: gridY[6], left: gridX[0], width: gridX[4] - gridX[0] },
            { class: 'line h8', top: gridY[7], left: gridX[1], width: gridX[3] - gridX[1] },
            { class: 'line h9', top: gridY[8], left: gridX[0], width: gridX[4] - gridX[0] }
        ];

        const verticalLines = [
            { class: 'line v1', left: gridX[0], top: gridY[2], height: gridY[6] - gridY[2] },
            { class: 'line v2', left: gridX[1], top: gridY[2], height: gridY[6] - gridY[2] },
            { class: 'line v3', left: gridX[2], top: gridY[0], height: gridY[8] - gridY[0] },
            { class: 'line v4', left: gridX[3], top: gridY[2], height: gridY[6] - gridY[2] },
            { class: 'line v5', left: gridX[4], top: gridY[2], height: gridY[6] - gridY[2] }
        ];

        const diagonalLines = [
            { class: 'line diagonal diag-1-25', startX: gridX[0], startY: gridY[0], endX: gridX[4], endY: gridY[4] },
            { class: 'line diagonal diag-25-41', startX: gridX[0], startY: gridY[8], endX: gridX[4], endY: gridY[4] },
            { class: 'line diagonal diag-45-21', startX: gridX[4], startY: gridY[8], endX: gridX[0], endY: gridY[4] },
            { class: 'line diagonal diag-21-5', startX: gridX[0], startY: gridY[4], endX: gridX[4], endY: gridY[0] },
            { class: 'line diagonal diag-11-35', startX: gridX[0], startY: gridY[2], endX: gridX[4], endY: gridY[6] },
            { class: 'line diagonal diag-31-15', startX: gridX[0], startY: gridY[6], endX: gridX[4], endY: gridY[2] }
        ];

        horizontalLines.forEach(line => {
            createLine(line.class, {
                top: `${line.top}%`,
                left: `${line.left}%`,
                width: `${line.width}%`,
                height: 'max(2px, 0.5vmin)',
                transform: 'translateY(-50%)'
            });
        });

        verticalLines.forEach(line => {
            createLine(line.class, {
                left: `${line.left}%`,
                top: `${line.top}%`,
                height: `${line.height}%`,
                width: 'max(2px, 0.5vmin)',
                transform: 'translateX(-50%)'
            });
        });

        diagonalLines.forEach(line => {
            const style = calculateDiagonal(line.startX, line.startY, line.endX, line.endY, boardWidth, boardHeight, false);
            createLine(line.class, style);
        });

        if (typeof GameLogic !== 'undefined' && typeof GameLogic.getInitialLayout === 'function') {
            const pointsLayout = GameLogic.getInitialLayout();
            pointsLayout.forEach(point => {
                createPoint(point.id, point.x, point.y, point.type, point.label || '', false);
            });
        } else {
            console.error('GameLogic.getInitialLayout is not defined.');
        }
    }

    function init(container) {
        containerElement = container;
    }

    return {
        init,
        drawBoard,
        setOpponentView,
        createPoint // Expose createPoint if needed by GameLogic or other parts
    };
})();
