// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCP2aav2rygSAdwNjtU_IBeiTK75IdX8Rw",
    authDomain: "guti-de4f7.firebaseapp.com",
    databaseURL: "https://guti-de4f7-default-rtdb.firebaseio.com",
    projectId: "guti-de4f7",
    storageBucket: "guti-de4f7.appspot.com", // Corrected storageBucket
    messagingSenderId: "160478542635",
    appId: "1:160478542635:web:a5ce81d97a395a5ee2a36e",
    measurementId: "G-XFL4CXGNNS"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();

function generateRoomCode() {
    return Math.random().toString(36).substring(2, 7).toUpperCase();
}

document.addEventListener('DOMContentLoaded', () => {
    const onlineLobbyPopup = document.getElementById('onlineLobbyPopup');
    const createRoomBtn = document.getElementById('createRoomBtn');
    const joinRoomBtn = document.getElementById('joinRoomBtn');
    const cancelOnlineLobbyBtn = document.getElementById('cancelOnlineLobbyBtn');
    const onlinePlayerNameInput = document.getElementById('onlinePlayerName');
    const roomCodeInput = document.getElementById('roomCode');
    const copyRoomCodeBtn = document.getElementById('copyRoomCodeBtn');
    const startGameOnlineBtn = document.getElementById('startGameOnlineBtn');
    const modeSelectionScreen = document.getElementById('modeSelectionScreen');
    const roomStatusInfo = document.getElementById('roomStatusInfo'); 
    const gameContainer = document.getElementById('gameContainer');
    const banner = document.querySelector('.banner');
    const adContainer = document.getElementById('adContainer');
    const player1BannerName = document.getElementById('player1BannerName');
    const player2BannerName = document.getElementById('player2BannerName');

    let currentRoomCode = localStorage.getItem('currentGameRoomCode');
    let currentPlayerName = localStorage.getItem('currentGamePlayerName');
    const fbAvailable = typeof window !== 'undefined' && typeof FBInstant !== 'undefined';
    let roomListener = null;

    // Function to clear stored room and player data
    function clearStoredGameData() {
        localStorage.removeItem('currentGameRoomCode');
        localStorage.removeItem('currentGamePlayerName');
        currentRoomCode = null;
        currentPlayerName = null;
    }

    // Prefill player name from FBInstant, if available
    if (fbAvailable) {
        try {
            const fbName = FBInstant.player && FBInstant.player.getName ? FBInstant.player.getName() : '';
            if (fbName && onlinePlayerNameInput) onlinePlayerNameInput.value = fbName;
        } catch(e) {
            console.warn('FBInstant player name fetch failed:', e);
        }
    }

    // Attempt to rejoin room on page load if data exists
    if (currentRoomCode && currentPlayerName) {
        // Hide mode selection, show lobby
        modeSelectionScreen.classList.add('hidden');
        onlineLobbyPopup.classList.remove('hidden');
        onlinePlayerNameInput.value = currentPlayerName;
        roomCodeInput.value = currentRoomCode;
        roomCodeInput.readOnly = true;
        createRoomBtn.classList.add('hidden');
        joinRoomBtn.classList.add('hidden');
        copyRoomCodeBtn.classList.remove('hidden');
        
        // Check room status and listen
        const roomRef = database.ref('rooms/' + currentRoomCode);
        roomRef.once('value').then(snapshot => {
            if (snapshot.exists()) {
                const roomData = snapshot.val();
                const players = roomData.players || {};
                if (players[currentPlayerName]) { // Check if this player is still part of the room
                    listenToRoomUpdates(currentRoomCode);
                    alert(`You rejoined room "${currentRoomCode}".`);
                } else {
                    alert('You were removed from the room or it is no longer available.');
                    clearStoredGameData();
                    // Show mode selection again
                    onlineLobbyPopup.classList.add('hidden');
                    modeSelectionScreen.classList.remove('hidden');
                    roomCodeInput.readOnly = false;
                    createRoomBtn.classList.remove('hidden');
                    joinRoomBtn.classList.remove('hidden');
                    copyRoomCodeBtn.classList.add('hidden');
                }
            } else {
                alert(`Room "${currentRoomCode}" is no longer available.`);
                clearStoredGameData();
                onlineLobbyPopup.classList.add('hidden');
                modeSelectionScreen.classList.remove('hidden');
                roomCodeInput.readOnly = false;
                createRoomBtn.classList.remove('hidden');
                joinRoomBtn.classList.remove('hidden');
                copyRoomCodeBtn.classList.add('hidden');
            }
        }).catch(error => {
            console.error('Error rejoining room:', error);
            alert('Failed to rejoin the room.');
            clearStoredGameData();
            onlineLobbyPopup.classList.add('hidden');
            modeSelectionScreen.classList.remove('hidden');
            roomCodeInput.readOnly = false;
            createRoomBtn.classList.remove('hidden');
            joinRoomBtn.classList.remove('hidden');
            copyRoomCodeBtn.classList.add('hidden');
        });
    }

    if (createRoomBtn) {
        createRoomBtn.addEventListener('click', () => {
            const playerName = onlinePlayerNameInput.value.trim();
            if (!playerName) {
                alert('Please enter your name.');
                return;
            }
            const newRoomCode = generateRoomCode();
            roomCodeInput.value = newRoomCode;
            roomCodeInput.readOnly = true; // Make input readonly after creating room
            copyRoomCodeBtn.classList.remove('hidden');
            database.ref('rooms/' + newRoomCode).set({
                players: {
                    [playerName]: { joined: true, isHost: true, name: playerName }
                },
                createdAt: firebase.database.ServerValue.TIMESTAMP,
                status: 'waiting'
            }).then(() => {
                alert(`Room "${newRoomCode}" created. Share this code with your friend to join.`);
                currentRoomCode = newRoomCode;
                currentPlayerName = playerName;
                localStorage.setItem('currentGameRoomCode', currentRoomCode);
                localStorage.setItem('currentGamePlayerName', currentPlayerName);
                listenToRoomUpdates(newRoomCode);
                createRoomBtn.classList.add('hidden'); // Hide create room button
                joinRoomBtn.classList.add('hidden'); // Hide join room button
            }).catch(error => {
                console.error('Error creating room:', error);
                alert('Failed to create room.');
            });
        });
    }

    if (joinRoomBtn) {
        joinRoomBtn.addEventListener('click', () => {
            const playerName = onlinePlayerNameInput.value.trim();
            const roomCodeToJoin = roomCodeInput.value.trim().toUpperCase();

            if (!playerName) {
                alert('Please enter your name.');
                return;
            }
            if (!roomCodeToJoin) {
                alert('Please enter the room code.');
                return;
            }
            roomCodeInput.readOnly = true; // Make input readonly after attempting to join

            const roomRef = database.ref('rooms/' + roomCodeToJoin);
            roomRef.once('value').then(snapshot => {
                if (snapshot.exists()) {
                    const roomData = snapshot.val();
                    const players = roomData.players || {};
                    const playerCount = Object.keys(players).length;

                    if (playerCount < 2) {
                        if (players[playerName]){
                            alert('A player with this name is already in the room. Please use another name.');
                            return;
                        }
                        roomRef.child('players/' + playerName).set({
                            joined: true,
                            isHost: false,
                            name: playerName
                        }).then(() => {
                            alert(`You successfully joined room "${roomCodeToJoin}".`);
                            currentRoomCode = roomCodeToJoin;
                            currentPlayerName = playerName;
                            localStorage.setItem('currentGameRoomCode', currentRoomCode);
                            localStorage.setItem('currentGamePlayerName', currentPlayerName);
                            listenToRoomUpdates(roomCodeToJoin); // Joiner also listens
                            createRoomBtn.classList.add('hidden');
                            joinRoomBtn.classList.add('hidden');
                        }).catch(error => {                             
                            roomCodeInput.readOnly = false; // Make input editable if join fails
                            console.error('Error joining room:', error);
                            alert('Failed to join the room.');
                        });
                    } else {
                        alert('This room is already full.');
                    }
                } else {
                    alert('Invalid room code or the room is no longer available.');
                }
            }).catch(error => {
                console.error('Error checking room:', error);
                alert('Failed to check the room.');
            });
        });
    }

    if (cancelOnlineLobbyBtn) {
        cancelOnlineLobbyBtn.addEventListener('click', () => {
            onlineLobbyPopup.classList.add('hidden');
            modeSelectionScreen.classList.remove('hidden');
            if (roomListener && currentRoomCode) {
                database.ref('rooms/' + currentRoomCode).off('value', roomListener); 
            }
            // Do not remove player from Firebase on cancel if they are in a stored game
            // Only clear local storage if they explicitly cancel and were not in a game that could be rejoined
            const playerRef = database.ref('rooms/' + currentRoomCode + '/players/' + currentPlayerName);
            playerRef.once('value', snapshot => {
                if (snapshot.exists()) {
                    // If player is host and only player, or if game not started, remove player
                    database.ref('rooms/' + currentRoomCode).once('value', roomSnapshot => {
                        const roomData = roomSnapshot.val();
                        if (roomData && roomData.players) {
                            const numPlayers = Object.keys(roomData.players).length;
                            const isHost = roomData.players[currentPlayerName] && roomData.players[currentPlayerName].isHost;
                            if (roomData.status === 'waiting' || (isHost && numPlayers === 1)) {
                                playerRef.remove().catch(err => console.error("Error removing player on cancel: ", err));
                                // If host leaves and room becomes empty, or was the only one, consider deleting room
                                if (isHost && numPlayers === 1) {
                                    database.ref('rooms/' + currentRoomCode).remove().catch(err => console.error("Error deleting room: ", err));
                                }
                            }       
                        }
                        clearStoredGameData(); // Clear local storage on explicit cancel
                    });
                } else {
                    clearStoredGameData(); // Player wasn't in room or room didn't exist
                }
            });
            
            roomStatusInfo.innerHTML = ''; 
            roomCodeInput.value = ''; // Clear room code input
            roomCodeInput.readOnly = false; // Make input editable again
            copyRoomCodeBtn.classList.add('hidden');
            startGameOnlineBtn.classList.add('hidden');
            startGameOnlineBtn.disabled = true;
            createRoomBtn.classList.remove('hidden'); 
            joinRoomBtn.classList.remove('hidden'); 
        });
    }

    if(copyRoomCodeBtn){
        copyRoomCodeBtn.addEventListener('click', () => {
            roomCodeInput.select();
            document.execCommand('copy');
            alert('Room code copied!');
        });
    }

    

    function listenToRoomUpdates(roomCode) {
        const roomRef = database.ref('rooms/' + roomCode);
        if (roomListener) { // Remove previous listener if any, to avoid multiple listeners on same room
            database.ref('rooms/' + (currentRoomCode || roomCode)).off('value', roomListener);
        }
        roomListener = roomRef.on('value', snapshot => {
            if (!snapshot.exists()) {
                alert('The host left or the room was deleted.');
                onlineLobbyPopup.classList.add('hidden');
                modeSelectionScreen.classList.remove('hidden');
                roomStatusInfo.innerHTML = '';
                if (roomListener && currentRoomCode) {
                    database.ref('rooms/' + currentRoomCode).off('value', roomListener);
                }
                clearStoredGameData();
                roomCodeInput.value = '';
                roomCodeInput.readOnly = false;
                createRoomBtn.classList.remove('hidden');
                joinRoomBtn.classList.remove('hidden');
                copyRoomCodeBtn.classList.add('hidden');
                startGameOnlineBtn.classList.add('hidden');
                startGameOnlineBtn.disabled = true;
                return;
            }
            const roomData = snapshot.val();
            const players = roomData.players || {};
            const playerCount = Object.keys(players).length;
            const playerNamesArray = Object.values(players).map(p => p.name);
            
            let hostName = "";
            for(const key in players){
                if(players[key].isHost) hostName = players[key].name;
            }

            if (roomData.status === 'waiting') {
                let statusMessage = `Game ID: <strong>${roomCode}</strong>`;
                if (hostName) {
                    statusMessage += `<br>Host: ${hostName}`;
                }
                if (playerCount === 1) {
                    statusMessage += `<br>Waiting for Player 2... (${playerCount}/2 players)`;
                } else if (playerCount === 2) {
                    statusMessage += `<br>Players: ${playerNamesArray.join(' and ')} <br>Game is starting... (${playerCount}/2 players)`;
                    // Only host should trigger game start
                    if (players[currentPlayerName] && players[currentPlayerName].isHost) {
                        // roomRef.update({ status: 'playing' }); // Host will click start game button
                        startGameOnlineBtn.classList.remove('hidden');
                        startGameOnlineBtn.disabled = false;
                    } else if (players[currentPlayerName] && !players[currentPlayerName].isHost) {
                        // For the joining player, also show the start game button but disabled, host controls it.
                        startGameOnlineBtn.classList.remove('hidden');
                        startGameOnlineBtn.disabled = true; 
                    }
                }
                roomStatusInfo.innerHTML = statusMessage;
            } else if (roomData.status === 'playing') {
                if (playerCount === 2) {
                    startGameOnline(roomCode, players, currentPlayerName);
                } else {
                    // A player might have left after game started, handle this (e.g., show message, end game)
                    roomStatusInfo.innerHTML = `Room ID: <strong>${roomCode}</strong> <br> A player disconnected.`;
                    // Potentially reset to waiting or end game
                }
            }
        });
    }

    function startGameOnline(roomCode, firebasePlayers, localPlayerName) {
        // Clear stored data once game starts successfully
        // clearStoredGameData(); // Moved this to be called only if game init is successful

        GameLogic.currentMode = 'online'; // Set current game mode

        // Detach the main room listener that handles lobby UI updates and game start triggering.
        // GameLogic.initOnline will set up its own listener for game state updates.
        if (roomListener) {
            console.log("Detaching main room listener in startGameOnline for room:", roomCode);
            database.ref('rooms/' + roomCode).off('value', roomListener);
            // roomListener = null; // Optional: nullify to prevent re-detachment issues
        }
        console.log(`Attempting to start online game in room ${roomCode} for ${localPlayerName}`);
        onlineLobbyPopup.classList.add('hidden');
        banner.classList.remove('hidden');
        gameContainer.classList.remove('hidden');
        adContainer.classList.remove('hidden');

        let p1Name, p2Name;
        for (const key in firebasePlayers) {
            if (firebasePlayers[key].isHost) p1Name = firebasePlayers[key].name;
            else p2Name = firebasePlayers[key].name;
        }
        
        player1BannerName.textContent = p1Name;
        player2BannerName.textContent = p2Name;

        // Set avatars from FBInstant, if available
        if (fbAvailable) {
            try {
                const bannerImages = document.querySelectorAll('.banner .player-info img');
                const selfId = FBInstant.player.getID && FBInstant.player.getID();
                if (FBInstant.context && FBInstant.context.getPlayersAsync) {
                    FBInstant.context.getPlayersAsync().then(players => {
                        players.forEach(p => {
                            const pid = p.getID ? p.getID() : null;
                            const photo = p.getPhoto ? p.getPhoto() : null;
                            if (!photo) return;
                            if (pid === selfId && bannerImages[0]) {
                                bannerImages[0].src = photo;
                            } else if (bannerImages[1]) {
                                bannerImages[1].src = photo;
                            }
                        });
                    }).catch(e => console.warn('getPlayersAsync failed:', e));
                } else {
                    const selfPhoto = FBInstant.player.getPhoto && FBInstant.player.getPhoto();
                    if (selfPhoto && bannerImages[0]) bannerImages[0].src = selfPhoto;
                }
            } catch(e) {
                console.warn('FB avatar setup failed:', e);
            }
        }

        if (typeof GameLogic !== 'undefined' && typeof GameLogic.initOnline === 'function') {
            if (typeof BoardRenderer !== 'undefined' && typeof BoardRenderer.init === 'function' && typeof BoardRenderer.drawBoard === 'function') {
                try {
                    console.log("Hiding lobby UI elements.");
                    createRoomBtn.classList.add('hidden');
                    joinRoomBtn.classList.add('hidden');
                    startGameOnlineBtn.classList.add('hidden');
                    roomStatusInfo.innerHTML = ''; 
                    copyRoomCodeBtn.classList.add('hidden');

                    console.log("Initializing BoardRenderer...");
                    const boardElementsContainer = document.querySelector('.board-elements-container');
                    if (!boardElementsContainer) {
                        throw new Error("Board elements container not found for BoardRenderer.init!");
                    }
                    BoardRenderer.init(boardElementsContainer);
                    console.log("Drawing board...");
                    BoardRenderer.drawBoard(); 
                    
                    console.log("Initializing GameLogic for online play...");
                    GameLogic.initOnline(boardElementsContainer, database, roomCode, localPlayerName, p1Name, p2Name, updateBannerScoresOnline, showWinPopupOnline);
                    BoardRenderer.setOpponentView(GameLogic.localPlayerColor === 'red');
                    console.log("Online game setup complete.");
                    clearStoredGameData(); // Clear local storage only after successful game initialization

                } catch (e) {
                    console.error('Error starting BoardRenderer or GameLogic.initOnline:', e);
                    alert('Failed to start online game board: ' + e.message);
                    // Revert UI
                    banner.classList.add('hidden');
                    gameContainer.classList.add('hidden');
                    adContainer.classList.add('hidden');
                    onlineLobbyPopup.classList.remove('hidden'); // Show lobby again
                    // Re-attach listener if game failed to start, so lobby updates continue
                    if(currentRoomCode) listenToRoomUpdates(currentRoomCode);
                }
            } else {
                 console.error('BoardRenderer is not ready.');
                 alert('Online game board renderer not found.');
                 banner.classList.add('hidden');
                 gameContainer.classList.add('hidden');
                 adContainer.classList.add('hidden');
                 onlineLobbyPopup.classList.remove('hidden');
                 if(currentRoomCode) listenToRoomUpdates(currentRoomCode);
            }
        } else {
            console.error('GameLogic.initOnline is not defined. Online mode cannot start.');
            alert('Failed to start online game. GameLogic is not configured correctly.');
            banner.classList.add('hidden');
            gameContainer.classList.add('hidden');
            adContainer.classList.add('hidden');
            onlineLobbyPopup.classList.remove('hidden');
            if(currentRoomCode) listenToRoomUpdates(currentRoomCode);
        }
    }

    function updateBannerScoresOnline() {
        try {
            const p1ScoreEl = document.getElementById('player1Score');
            const p2ScoreEl = document.getElementById('player2Score');
            if (typeof GameLogic !== 'undefined' && GameLogic.scores && p1ScoreEl && p2ScoreEl) {
                p1ScoreEl.textContent = `Score: ${GameLogic.scores.player1}`;
                p2ScoreEl.textContent = `Score: ${GameLogic.scores.player2}`;
            }
        } catch(e) {}
    }

    // Placeholder for online win popup - GameLogic.initOnline should handle this via Firebase
    function showWinPopupOnline(winnerName, score) {
        const winPopup = document.getElementById('winPopup');
        const winMessageElement = document.getElementById('winMessage');
        const winScoreElement = document.getElementById('winScore');
        const playAgainBtn = document.getElementById('playAgainBtn');
        const exitToMenuBtn = document.getElementById('exitToMenuBtn');

        winMessageElement.textContent = `${winnerName} wins!`;
        winScoreElement.textContent = `You captured ${score} pieces.`;
        winPopup.classList.remove('hidden');

        // Remove previous listeners to avoid multiple triggers
        const newPlayAgainBtn = playAgainBtn.cloneNode(true);
        playAgainBtn.parentNode.replaceChild(newPlayAgainBtn, playAgainBtn);

        const newExitToMenuBtn = exitToMenuBtn.cloneNode(true);
        exitToMenuBtn.parentNode.replaceChild(newExitToMenuBtn, exitToMenuBtn);

        newPlayAgainBtn.addEventListener('click', () => {
            winPopup.classList.add('hidden');
            // Signal to the other player to restart or wait for host to restart
            if (currentRoomCode) {
                const roomRef = database.ref('rooms/' + currentRoomCode);
                // Reset game state in Firebase, perhaps by setting status to 'waiting_for_rematch'
                // Or simply navigate back to lobby for players to decide
                // For simplicity, let's navigate back to lobby
                roomRef.update({ status: 'waiting', board: null, turn: null, scores: {player1:0, player2:0} }); 
            }
            // UI reset to lobby state
            const bannerEl = document.querySelector('.banner');
            if (bannerEl) bannerEl.classList.add('hidden');
            document.getElementById('gameContainer').classList.add('hidden');
            document.getElementById('adContainer').classList.add('hidden');
            document.getElementById('onlineLobbyPopup').classList.remove('hidden');
            listenToRoomUpdates(currentRoomCode); // Re-listen to room for rematch or new game
        });

        newExitToMenuBtn.addEventListener('click', () => {
            winPopup.classList.add('hidden');
            if (currentRoomCode) {
                const playerRef = database.ref('rooms/' + currentRoomCode + '/players/' + currentPlayerName);
                playerRef.remove(); // Remove player from room
                // If host leaves, or room becomes empty, consider deleting room or notifying other player
                database.ref('rooms/' + currentRoomCode).once('value', snapshot => {
                    const roomData = snapshot.val();
                    if(roomData && roomData.players){
                        const remainingPlayers = Object.keys(roomData.players);
                        if(remainingPlayers.length === 0 || (roomData.players[currentPlayerName] && roomData.players[currentPlayerName].isHost)){
                            database.ref('rooms/' + currentRoomCode).remove(); // Delete room if host leaves or it's empty
                        }
                    }
                });
            }
            clearStoredGameData();
            // UI reset to main menu
            const bannerEl = document.querySelector('.banner');
            if (bannerEl) bannerEl.classList.add('hidden');
            document.getElementById('gameContainer').classList.add('hidden');
            document.getElementById('adContainer').classList.add('hidden');
            document.getElementById('onlineLobbyPopup').classList.add('hidden');
            document.getElementById('modeSelectionScreen').classList.remove('hidden');
            if (roomListener && currentRoomCode) {
                database.ref('rooms/' + currentRoomCode).off('value', roomListener);
            }
            const roomCodeInputEl = document.getElementById('roomCode');
            if (roomCodeInputEl) {
                roomCodeInputEl.value = '';
                roomCodeInputEl.readOnly = false;
            }
            document.getElementById('createRoomBtn').classList.remove('hidden');
            document.getElementById('joinRoomBtn').classList.remove('hidden');
            document.getElementById('copyRoomCodeBtn').classList.add('hidden');
            document.getElementById('startGameOnlineBtn').classList.add('hidden');
            document.getElementById('startGameOnlineBtn').disabled = true;
            document.getElementById('roomStatusInfo').innerHTML = '';
        });
    }

    if(startGameOnlineBtn){
        startGameOnlineBtn.addEventListener('click', () => {
            if(currentRoomCode && currentPlayerName){
                const roomRef = database.ref('rooms/' + currentRoomCode);
                roomRef.once('value').then(snapshot => {
                    if(snapshot.exists()){
                        const roomData = snapshot.val();
                        const players = roomData.players || {};
                        if(players[currentPlayerName] && players[currentPlayerName].isHost && Object.keys(players).length === 2){
                            roomRef.update({ status: 'playing' });
                            // startGameOnline will be called by the listener when status changes to 'playing'
                        } else {
                            alert('Two players are required and you must be the host to start the game.');
                        }
                    } else {
                        alert('Room is no longer available.');
                    }
                }).catch(error => {
                    console.error('Error starting game:', error);
                    alert('Failed to start the game.');
                });
            }
        });
    }

    // If launched inside a Messenger context, auto use context ID as room
    if (fbAvailable && typeof FBInstant.context !== 'undefined') {
        try {
            const ctxId = FBInstant.context.getID && FBInstant.context.getID();
            if (ctxId) {
                roomCodeInput.value = ctxId;
                roomCodeInput.readOnly = true;
                copyRoomCodeBtn.classList.remove('hidden');

                const playerName = (onlinePlayerNameInput.value || '').trim() || 'Player';
                const roomRef = database.ref('rooms/' + ctxId);
                roomRef.once('value').then(snapshot => {
                    if (!snapshot.exists()) {
                        roomRef.set({
                            players: {
                                [playerName]: { joined: true, isHost: true, name: playerName, fbId: FBInstant.player.getID() }
                            },
                            createdAt: firebase.database.ServerValue.TIMESTAMP,
                            status: 'waiting',
                            contextId: ctxId
                        }).then(() => {
                            currentRoomCode = ctxId;
                            currentPlayerName = playerName;
                            localStorage.setItem('currentGameRoomCode', currentRoomCode);
                            localStorage.setItem('currentGamePlayerName', currentPlayerName);
                            listenToRoomUpdates(ctxId);
                            onlineLobbyPopup.classList.remove('hidden');
                            modeSelectionScreen.classList.add('hidden');
                        });
                    } else {
                        const roomData = snapshot.val();
                        const players = roomData.players || {};
                        const alreadyInRoom = Object.values(players).some(p => p.fbId === (FBInstant.player.getID && FBInstant.player.getID()));
                        if (!alreadyInRoom && Object.keys(players).length < 2) {
                            roomRef.child('players/' + playerName).set({
                                joined: true,
                                isHost: false,
                                name: playerName,
                                fbId: FBInstant.player.getID()
                            }).then(() => {
                                currentRoomCode = ctxId;
                                currentPlayerName = playerName;
                                localStorage.setItem('currentGameRoomCode', currentRoomCode);
                                localStorage.setItem('currentGamePlayerName', currentPlayerName);
                                listenToRoomUpdates(ctxId);
                                onlineLobbyPopup.classList.remove('hidden');
                                modeSelectionScreen.classList.add('hidden');
                            });
                        } else {
                            currentRoomCode = ctxId;
                            currentPlayerName = playerName;
                            localStorage.setItem('currentGameRoomCode', currentRoomCode);
                            localStorage.setItem('currentGamePlayerName', currentPlayerName);
                            listenToRoomUpdates(ctxId);
                            onlineLobbyPopup.classList.remove('hidden');
                            modeSelectionScreen.classList.add('hidden');
                        }
                    }
                }).catch(err => console.error('Context room handling error:', err));
            }
        } catch(e) {
            console.warn('FBInstant context detection failed:', e);
        }
    }

});
