// gameLogic.js

const GameLogic = {
    database: null, // For Firebase
    roomCode: null, // For Firebase
    localPlayerName: null, // Current player's name in online mode
    localPlayerColor: null, // The color of the current player on this device ('red' or 'green')
    player1Name: null, // Online P1 name (usually host)
    player2Name: null, // Online P2 name (usually joined player)
    onlineGameStateListener: null, // Firebase listener for game state
    firebaseListenersAttached: false, // Flag to track if listeners are active

    isComputerMode: false,
    computerPlayerInstance: null,
    computerPlayerColor: 'red', // কম্পিউটার প্লেয়ারের রঙ (এখন প্লেয়ার ১)
    processingComputerMove: false, // কম্পিউটার যখন চাল দিচ্ছে তখন এই ফ্ল্যাগ সেট করা হবে
    gameOver: false, // খেলা শেষ হয়েছে কিনা তা ট্র্যাক করার জন্য
    boardElementsContainer: null,
    currentPlayer: 'red', // 'red' or 'green'
    selectedPiece: null, // Stores pointData of the selected piece
    mustCapture: false, // নিশ্চিত করুন এটি false
    consecutiveCapture: false,
    captureTimeoutId: null, // টাইমার আইডি সংরক্ষণের জন্য
    redPiecesCount: 16,
    greenPiecesCount: 16,
    updateScoreCallback: null,
    showWinPopupCallback: null,
    getPlayer1NameCallback: null,
    getPlayer2NameCallback: null,
    scores: { player1: 0, player2: 0 }, // স্কোর সংরক্ষণের জন্য অবজেক্ট

    gridX: [5, 27.5, 50, 72.5, 95],
    gridY: [5, 16.25, 27.5, 38.75, 50, 61.25, 72.5, 83.75, 95],

    pointCoordinates: [], // Stores { x, y, id, type, element }
    pointIdCounter: 0,
    adj: new Map(), // Stores pointId -> [neighborPointId]

    getInitialLayout: function() {
        this.pointIdCounter = 0; // Reset counter each time layout is generated
        const layout = [
            { x: this.gridX[0], y: this.gridY[0], type: 'red-piece' }, { x: this.gridX[2], y: this.gridY[0], type: 'red-piece' }, { x: this.gridX[4], y: this.gridY[0], type: 'red-piece' },
            { x: this.gridX[1], y: this.gridY[1], type: 'red-piece' }, { x: this.gridX[2], y: this.gridY[1], type: 'red-piece' }, { x: this.gridX[3], y: this.gridY[1], type: 'red-piece' },
            { x: this.gridX[0], y: this.gridY[2], type: 'red-piece' }, { x: this.gridX[1], y: this.gridY[2], type: 'red-piece' }, { x: this.gridX[2], y: this.gridY[2], type: 'red-piece' }, { x: this.gridX[3], y: this.gridY[2], type: 'red-piece' }, { x: this.gridX[4], y: this.gridY[2], type: 'red-piece' },
            { x: this.gridX[0], y: this.gridY[3], type: 'red-piece' }, { x: this.gridX[1], y: this.gridY[3], type: 'red-piece' }, { x: this.gridX[2], y: this.gridY[3], type: 'red-piece' }, { x: this.gridX[3], y: this.gridY[3], type: 'red-piece' }, { x: this.gridX[4], y: this.gridY[3], type: 'red-piece' },
            { x: this.gridX[0], y: this.gridY[4], type: '' }, { x: this.gridX[1], y: this.gridY[4], type: '' }, { x: this.gridX[2], y: this.gridY[4], type: '' }, { x: this.gridX[3], y: this.gridY[4], type: '' }, { x: this.gridX[4], y: this.gridY[4], type: '' },
            { x: this.gridX[0], y: this.gridY[5], type: 'green-piece' }, { x: this.gridX[1], y: this.gridY[5], type: 'green-piece' }, { x: this.gridX[2], y: this.gridY[5], type: 'green-piece' }, { x: this.gridX[3], y: this.gridY[5], type: 'green-piece' }, { x: this.gridX[4], y: this.gridY[5], type: 'green-piece' },
            { x: this.gridX[0], y: this.gridY[6], type: 'green-piece' }, { x: this.gridX[1], y: this.gridY[6], type: 'green-piece' }, { x: this.gridX[2], y: this.gridY[6], type: 'green-piece' }, { x: this.gridX[3], y: this.gridY[6], type: 'green-piece' }, { x: this.gridX[4], y: this.gridY[6], type: 'green-piece' },
            { x: this.gridX[1], y: this.gridY[7], type: 'green-piece' }, { x: this.gridX[2], y: this.gridY[7], type: 'green-piece' }, { x: this.gridX[3], y: this.gridY[7], type: 'green-piece' },
            { x: this.gridX[0], y: this.gridY[8], type: 'green-piece' }, { x: this.gridX[2], y: this.gridY[8], type: 'green-piece' }, { x: this.gridX[4], y: this.gridY[8], type: 'green-piece' }
        ];

        const resultLayout = layout.map(p => ({ ...p, id: this.pointIdCounter++ }));
        return resultLayout;
    },

    flipPerspective: function(pointData) {
        return pointData;
    },

    init: function(boardElementsContainer, updateScoreCb, showWinPopupCb, getP1NameCb, getP2NameCb, isComputer) { // isComputer প্যারামিটার যোগ করা হয়েছে
        this.scores = { player1: 0, player2: 0 };
        this.boardElementsContainer = boardElementsContainer;
        if (!this.boardElementsContainer) {
            console.error("Board elements container not found for GameLogic initialization!");
            return;
        }
        this.updateScoreCallback = updateScoreCb;
        this.showWinPopupCallback = showWinPopupCb;
        this.getPlayer1NameCallback = getP1NameCb;
        this.getPlayer2NameCallback = getP2NameCb;
        
        this.isComputerMode = !!isComputer; // বুলিয়ান নিশ্চিত করুন
        this.gameOver = false; // খেলার শেষ অবস্থা রিসেট করুন
        this.processingComputerMove = false; // কম্পিউটার মুভ প্রসেসিং রিসেট করুন

        if (this.isComputerMode) {
            if (typeof ComputerPlayer !== 'undefined') {
                // কম্পিউটার প্লেয়ার ১ হিসেবে খেলবে এবং তার রঙ হবে লাল
                this.computerPlayerInstance = new ComputerPlayer(1); 
                this.computerPlayerColor = 'red';
                console.log("Computer mode enabled. Player 1 is Computer.");
            } else {
                console.error("ComputerPlayer class not found. Ensure computerPlayer.js is loaded. Falling back to 2-player mode.");
                this.isComputerMode = false;
                this.computerPlayerInstance = null;
            }
        } else {
            this.computerPlayerInstance = null;
        }

        // currentPlayer নির্ধারণ করার আগে কম্পিউটার মোড এবং রঙ সেট করা হয়েছে তা নিশ্চিত করুন
        // যদি কম্পিউটার মোড হয় এবং কম্পিউটার প্লেয়ার ১ (লাল) হয়, তাহলে প্রথম চাল কম্পিউটারের হতে পারে
        // অথবা যদি কম্পিউটার প্লেয়ার ২ (সবুজ) হয়, এবং দৈবচয়নে সবুজ শুরু করে, তাহলেও কম্পিউটারের চাল হতে পারে।
        // যেহেতু কম্পিউটার এখন প্লেয়ার ১ (লাল), তাই যদি দৈবচয়নে লাল শুরু করে, তাহলে কম্পিউটার শুরু করবে।
        // যদি দৈবচয়নে সবুজ শুরু করে, তাহলে ব্যবহারকারী (প্লেয়ার ২) শুরু করবে।

        this.initializeBoardAndLogic(); // এটি currentPlayer সেট করে

        // যদি কম্পিউটার মোড হয় এবং প্রথম চাল কম্পিউটারের হয় এবং খেলা শেষ না হয়ে থাকে
        if (!this.gameOver && this.isComputerMode && this.currentPlayer === this.computerPlayerColor) {
            console.log("First move is Computer's. Computer is moving...");
            this.makeComputerMove();
        }
    },

    renderBoard: function() {
        this.pointCoordinates.forEach(pData => {
            if (pData.element) {
                pData.element.classList.remove('red-piece', 'green-piece', 'selected', 'valid-move');
                // Clear existing piece div if any
                const pieceDiv = pData.element.querySelector('.piece');
                if (pieceDiv) {
                    pData.element.removeChild(pieceDiv);
                }
                // Clear text label if any (for empty points that might have had labels)
                if (!pData.type) { // if it's an empty spot
                    const existingLabel = Array.from(pData.element.childNodes).find(node => node.nodeType === Node.TEXT_NODE);
                    if (existingLabel) {
                        pData.element.removeChild(existingLabel);
                    }
                }
            }
        });

        this.pointCoordinates.forEach(pData => {
            if (pData.element) {
                if (pData.type === 'red-piece' || pData.type === 'green-piece') {
                    pData.element.classList.add(pData.type);
                    const piece = document.createElement('div');
                    piece.className = `piece ${pData.type.split('-')[0]}`;
                    pData.element.appendChild(piece);
                } else {
                    // If it's an empty point that should have a label (e.g., from initial setup)
                    // This part might need to be reconciled with how index.html's createPoint handles labels.
                    // For now, game logic primarily deals with pieces.
                }
            }
        });

        if (this.selectedPiece && this.selectedPiece.element) {
            this.selectedPiece.element.classList.add('selected');
        }

        if (this.selectedPiece) {
            const moves = this.getPossibleMoves(this.selectedPiece, this.mustCapture || this.consecutiveCapture);
            moves.forEach(move => {
                const targetPointElement = this.getPointDataById(move.targetPointData.id)?.element;
                if (targetPointElement) {
                    targetPointElement.classList.add('valid-move');
                }
            });
        }

        this.updateTurnIndicator();
        this.updateMustCaptureIndicator();
    },

    initializeBoardAndLogic: function() {
        this.pointCoordinates.length = 0;
        this.adj.clear();
        // pointIdCounter is handled by getInitialLayout
        
        // প্রথম খেলোয়াড় নির্ধারণ। যদি কম্পিউটার মোড হয়, এবং কম্পিউটার লাল হয়, 
        // তাহলে ব্যবহারকারী সবুজ হিসেবে খেলবে।
        // যদি কম্পিউটার মোড না হয়, তাহলে আগের মতোই দৈবচয়নে প্লেয়ার নির্ধারণ হবে।
        if (this.isComputerMode && this.computerPlayerColor === 'red') {
            // কম্পিউটার লাল, তাই প্রথম চাল দৈবচয়নে হতে পারে।
            // যদি কম্পিউটার প্রথম চাল দেয়, currentPlayer হবে 'red'
            // যদি ব্যবহারকারী প্রথম চাল দেয়, currentPlayer হবে 'green'
            this.currentPlayer = Math.random() < 0.5 ? 'red' : 'green'; 
            console.log(`In computer mode, first player: ${this.currentPlayer}`);
        } else if (this.isComputerMode && this.computerPlayerColor === 'green') {
            // এই পরিস্থিতি এখন আর প্রযোজ্য নয় কারণ কম্পিউটার সবসময় লাল
            this.currentPlayer = Math.random() < 0.5 ? 'red' : 'green'; 
        } else {
            this.currentPlayer = Math.random() < 0.5 ? 'red' : 'green'; // সাধারণ মোড
        }
        this.selectedPiece = null;
        this.mustCapture = false;
        this.consecutiveCapture = false;
        this.redPiecesCount = 16;
        this.greenPiecesCount = 16;
        this.scores = { player1: 0, player2: 0 }; // বোর্ড এবং লজিক শুরু করার সময় স্কোর রিসেট করুন

        const initialLayoutWithIds = this.getInitialLayout(); // Get layout with IDs

        initialLayoutWithIds.forEach(pInfo => {
            // Find the DOM element created by index.html using data-point-id
            const pointElement = this.boardElementsContainer.querySelector(`.point[data-point-id="${pInfo.id}"]`);
            if (!pointElement) {
                console.error(`DOM element for point ID ${pInfo.id} not found.`);
            }
            this.pointCoordinates.push({ ...pInfo, element: pointElement });
            this.adj.set(pInfo.id, []);
        });
        
        const pointIndexToId = (xIdx, yIdx) => {
            const targetX = this.gridX[xIdx];
            const targetY = this.gridY[yIdx];
            const found = this.pointCoordinates.find(p => Math.abs(p.x - targetX) < 0.1 && Math.abs(p.y - targetY) < 0.1);
            return found ? found.id : -1;
        };

        const connections = [];
        connections.push([[0,0],[2,0]], [[2,0],[4,0]]);
        connections.push([[1,1],[2,1]], [[2,1],[3,1]]);
        connections.push([[0,2],[1,2]], [[1,2],[2,2]], [[2,2],[3,2]], [[3,2],[4,2]]);
        connections.push([[0,3],[1,3]], [[1,3],[2,3]], [[2,3],[3,3]], [[3,3],[4,3]]);
        connections.push([[0,4],[1,4]], [[1,4],[2,4]], [[2,4],[3,4]], [[3,4],[4,4]]);
        connections.push([[0,5],[1,5]], [[1,5],[2,5]], [[2,5],[3,5]], [[3,5],[4,5]]);
        connections.push([[0,6],[1,6]], [[1,6],[2,6]], [[2,6],[3,6]], [[3,6],[4,6]]);
        connections.push([[1,7],[2,7]], [[2,7],[3,7]]);
        connections.push([[0,8],[2,8]], [[2,8],[4,8]]);
        connections.push([[2,0],[2,1]], [[2,1],[2,2]], [[2,2],[2,3]], [[2,3],[2,4]], [[2,4],[2,5]], [[2,5],[2,6]], [[2,6],[2,7]], [[2,7],[2,8]]);
        connections.push([[0,2],[0,3]], [[0,3],[0,4]], [[0,4],[0,5]], [[0,5],[0,6]]);
        connections.push([[1,2],[1,3]], [[1,3],[1,4]], [[1,4],[1,5]], [[1,5],[1,6]]);
        connections.push([[3,2],[3,3]], [[3,3],[3,4]], [[3,4],[3,5]], [[3,5],[3,6]]);
        connections.push([[4,2],[4,3]], [[4,3],[4,4]], [[4,4],[4,5]], [[4,5],[4,6]]);
        connections.push( [[0,2],[1,3]], [[1,3],[2,4]], [[2,4],[3,5]], [[3,5],[4,6]] );
        connections.push( [[0,6],[1,5]], [[1,5],[2,4]], [[2,4],[3,3]], [[3,3],[4,2]] );
        connections.push( [[0,0],[1,1]], [[1,1],[2,2]], [[2,2],[3,3]], [[3,3],[4,4]] );
        connections.push( [[0,8],[1,7]], [[1,7],[2,6]], [[2,6],[3,5]], [[3,5],[4,4]] );
        connections.push( [[4,8],[3,7]], [[3,7],[2,6]], [[2,6],[1,5]], [[1,5],[0,4]] );
        connections.push( [[0,4],[1,3]], [[1,3],[2,2]], [[2,2],[3,1]], [[3,1],[4,0]] );

        connections.forEach(conn => {
            const p1_indices = conn[0];
            const p2_indices = conn[1];
            const id1 = pointIndexToId(p1_indices[0], p1_indices[1]);
            const id2 = pointIndexToId(p2_indices[0], p2_indices[1]);

            if (id1 !== -1 && id2 !== -1) {
                this.adj.get(id1).push(id2);
                this.adj.get(id2).push(id1);
            }
        });

        this.renderBoard(); 
        this.checkNoValidMoves(); 
    },

    getPointDataById: function(id) {
        return this.pointCoordinates.find(p => p.id === id);
    },

    handlePointClick: function(clickedDivElement) {
        // Check if the clicked piece belongs to the current player
        const clickedPointIdInitial = parseInt(clickedDivElement.dataset.pointId, 10);
        const clickedPointDataInitial = this.getPointDataById(clickedPointIdInitial);

        if (clickedPointDataInitial && clickedPointDataInitial.type !== '' && !this.isCurrentPlayerPiece(clickedPointDataInitial) && !this.selectedPiece) {
            console.log("It's not your turn or not your piece.");
            return; // Do nothing if it's not the current player's piece and no piece is selected
        }

        // If a piece is selected, and the clicked point is another piece of the current player (not a valid move target)
        if (this.selectedPiece && clickedPointDataInitial && clickedPointDataInitial.type !== '' && this.isCurrentPlayerPiece(clickedPointDataInitial) && clickedPointDataInitial.id !== this.selectedPiece.id) {
            const validMovesForSelected = this.getPossibleMoves(this.selectedPiece, this.mustCapture || this.consecutiveCapture);
            const isClickedPointAValidMoveTarget = validMovesForSelected.some(m => m.targetPointData.id === clickedPointDataInitial.id);
            if (!isClickedPointAValidMoveTarget) {
                 // Allow re-selecting another piece of the current player if not in consecutive capture mode
                if (!this.consecutiveCapture) {
                    this.selectPiece(clickedPointDataInitial);
                    this.renderBoard();
                    return;
                }
            } 
        }
        if (this.gameOver) {
            return;
        }
        if (this.database && this.localPlayerColor && this.localPlayerColor !== this.currentPlayer) {
            return;
        }
        // যদি কম্পিউটার মোড হয় এবং কম্পিউটারের চাল দেওয়ার সময় হয় বা কম্পিউটার চাল প্রসেস করছে
        if (this.isComputerMode && this.currentPlayer === this.computerPlayerColor) {
            if (this.processingComputerMove) {
                return;
            }
            return; // মানুষের ক্লিক উপেক্ষা করুন
        }

        if (!clickedDivElement || !clickedDivElement.dataset || !clickedDivElement.dataset.pointId) return;
        const clickedPointId = parseInt(clickedDivElement.dataset.pointId, 10);
        const clickedPointData = this.getPointDataById(clickedPointId);

        if (!clickedPointData) return;

        if (this.selectedPiece) {
            const validMoves = this.getPossibleMoves(this.selectedPiece, this.mustCapture || this.consecutiveCapture);
            const move = validMoves.find(m => m.targetPointData.id === clickedPointData.id);

            if (move) { 
                const gameOver = this.movePiece(this.selectedPiece, clickedPointData, move.isCapture, move.capturedPointData);
                if (gameOver) return;

                let moveSuccessful = false;
                if (move.isCapture) {
                    const furtherCaptures = this.getPossibleMoves(clickedPointData, true).filter(m => m.isCapture);
                    if (furtherCaptures.length > 0) {
                        this.selectedPiece = clickedPointData;
                        this.consecutiveCapture = true;
                        this.renderBoard();
                        this.syncOnlineState();
                        clearTimeout(this.captureTimeoutId); 
                        this.captureTimeoutId = setTimeout(() => {
                            if (this.consecutiveCapture) { 
                            console.log("No move within 3 seconds, switching turn.");
                                this.consecutiveCapture = false; 
                                this.switchPlayer();
                            }
                        }, 3000);
                    } else {
                        clearTimeout(this.captureTimeoutId);
                        this.consecutiveCapture = false;
                        this.switchPlayer();
                    }
                    moveSuccessful = true;
                } else {
                    clearTimeout(this.captureTimeoutId);
                    this.consecutiveCapture = false;
                    this.switchPlayer();
                }
                moveSuccessful = true;
            } else if (clickedPointData.id === this.selectedPiece.id) { 
                this.deselectPiece();
            }
            // Ensure player switch only happens after a successful move or when capture sequence ends
            if (moveSuccessful && !this.consecutiveCapture) {
                // The switchPlayer is already called in the appropriate places above if a move was made.
                // If no move was made (e.g. deselection or invalid click), no switch should happen here.
            } else if (!moveSuccessful && !this.consecutiveCapture && this.selectedPiece && clickedPointData.id !== this.selectedPiece.id && !this.isCurrentPlayerPiece(clickedPointData)) {
                // If a piece is selected, and an invalid non-player spot is clicked, deselect
                this.deselectPiece();
            } else if (this.isCurrentPlayerPiece(clickedPointData) && !this.consecutiveCapture) { 
                this.selectPiece(clickedPointData);
            } else {
                 this.deselectPiece();
            }
        } else if (this.isCurrentPlayerPiece(clickedPointData) && !this.consecutiveCapture) { 
            this.selectPiece(clickedPointData);
        }
    },

    isCurrentPlayerPiece: function(pointData) {
        return pointData && pointData.type && pointData.type.startsWith(this.currentPlayer);
    },
    
    isOpponentPiece: function(pointData) {
        if (!pointData || !pointData.type) return false;
        const opponentColor = this.currentPlayer === 'red' ? 'green' : 'red';
        return pointData.type.startsWith(opponentColor);
    },

    selectPiece: function(pointData) {
        if (this.consecutiveCapture && this.selectedPiece && pointData.id !== this.selectedPiece.id) {
            return; 
        }
        this.selectedPiece = pointData;
        this.renderBoard();
    },

    deselectPiece: function() {
        this.selectedPiece = null;
        this.renderBoard();
    },

    movePiece: function(fromPointData, toPointData, isCapture, capturedPointData) {
        const flippedFromPoint = this.flipPerspective(fromPointData);
        const flippedToPoint = this.flipPerspective(toPointData);
        const flippedCapturedPoint = capturedPointData ? this.flipPerspective(capturedPointData) : null;

        // Update the piece types
        flippedToPoint.type = flippedFromPoint.type;
        flippedFromPoint.type = ''; 

        if (isCapture && flippedCapturedPoint) {
            const capturedPieceOriginalType = flippedCapturedPoint.type;
            flippedCapturedPoint.type = ''; 
            // Update piece counts and scores
            if (capturedPieceOriginalType === 'red-piece') {
                this.redPiecesCount--;
                if (this.currentPlayer === 'green') { // Green captured red
                    this.scores.player2++;
                }
            } else if (capturedPieceOriginalType === 'green-piece') {
                this.greenPiecesCount--;
                if (this.currentPlayer === 'red') { // Red captured green
                    this.scores.player1++;
                }
            }

            if (this.updateScoreCallback) {
                this.updateScoreCallback();
            }
        }
        
        if (this.redPiecesCount === 0 || this.greenPiecesCount === 0) {
            this.renderBoard(); 
            setTimeout(() => { 
                const winnerColor = flippedToPoint.type.split('-')[0];
                const winnerName = winnerColor === 'red' ? (this.getPlayer1NameCallback ? this.getPlayer1NameCallback() : 'Red') : (this.getPlayer2NameCallback ? this.getPlayer2NameCallback() : 'Green');
                const winnerTotalCaptures = winnerColor === 'red' ? (16 - this.greenPiecesCount) : (16 - this.redPiecesCount);
                if (this.showWinPopupCallback) {
                    this.showWinPopupCallback(winnerName, winnerTotalCaptures);
                } else {
                    alert(`${winnerName} wins!`);
                }
            }, 10);
            if (this.database && this.roomCode) {
                const roomRef = this.database.ref('rooms/' + this.roomCode);
                const boardState = this.pointCoordinates.map(p => ({ id: p.id, x: p.x, y: p.y, type: p.type }));
                const winnerColor = flippedToPoint.type.split('-')[0];
                const winnerNameOnline = winnerColor === 'red' ? this.player1Name : this.player2Name;
                roomRef.update({
                    board: boardState,
                    turn: this.currentPlayer,
                    scores: this.scores,
                    redPiecesCount: this.redPiecesCount,
                    greenPiecesCount: this.greenPiecesCount,
                    gameOver: true,
                    winner: winnerNameOnline,
                    mustCapture: this.mustCapture,
                    consecutiveCapture: false,
                    selectedPieceIdForConsecutiveCapture: null
                });
            }
            return true; 
        }
        return false; 
    },

    syncOnlineState: function() {
        if (!this.database || !this.roomCode) return;
        const roomRef = this.database.ref('rooms/' + this.roomCode);
        const boardState = this.pointCoordinates.map(p => ({ id: p.id, x: p.x, y: p.y, type: p.type }));
        roomRef.update({
            board: boardState,
            turn: this.currentPlayer,
            scores: this.scores,
            redPiecesCount: this.redPiecesCount,
            greenPiecesCount: this.greenPiecesCount,
            gameOver: this.gameOver,
            mustCapture: this.mustCapture,
            consecutiveCapture: this.consecutiveCapture,
            selectedPieceIdForConsecutiveCapture: this.consecutiveCapture && this.selectedPiece ? this.selectedPiece.id : null
        });
    },

    switchPlayer: function() {
        clearTimeout(this.captureTimeoutId); 
        this.currentPlayer = (this.currentPlayer === 'red') ? 'green' : 'red';
        // this.mustCapture remains unchanged in non-mandatory capture mode
        this.selectedPiece = null; 
        this.consecutiveCapture = false; 
        this.renderBoard(); 
        
        const noMovesForCurrentPlayer = this.checkNoValidMoves(); // এটি খেলা শেষ করতে পারে
        
        if (this.gameOver || noMovesForCurrentPlayer) {
            return; // খেলা শেষ বা বর্তমান প্লেয়ারের কোনো চাল নেই
        }

        // যদি কম্পিউটার মোড হয়, বর্তমান প্লেয়ার কম্পিউটার হয় এবং খেলা শেষ না হয়ে থাকে
        if (this.isComputerMode && this.currentPlayer === this.computerPlayerColor && !this.gameOver) {
            this.makeComputerMove();
        }
        if (this.database && this.roomCode) {
            const roomRef = this.database.ref('rooms/' + this.roomCode);
            const boardState = this.pointCoordinates.map(p => ({ id: p.id, x: p.x, y: p.y, type: p.type }));
            roomRef.update({
                board: boardState,
                turn: this.currentPlayer,
                scores: this.scores,
                redPiecesCount: this.redPiecesCount,
                greenPiecesCount: this.greenPiecesCount,
                gameOver: this.gameOver,
                mustCapture: this.mustCapture,
                consecutiveCapture: this.consecutiveCapture,
                selectedPieceIdForConsecutiveCapture: null
            });
        }
    },

    checkNoValidMoves: function() {
        let canMove = false;
        for (const pData of this.pointCoordinates) {
            if (this.isCurrentPlayerPiece(pData)) {
                const moves = this.getPossibleMoves(pData, this.mustCapture); 
                if (moves.length > 0) {
                    canMove = true;
                    break;
                }
            }
        }
        if (!canMove) {
            if (this.redPiecesCount > 0 && this.greenPiecesCount > 0) {
                this.renderBoard();
                setTimeout(() => {
                    const winnerColor = this.currentPlayer === 'red' ? 'green' : 'red';
                    const winnerName = winnerColor === 'red' ? (this.getPlayer1NameCallback ? this.getPlayer1NameCallback() : 'Red') : (this.getPlayer2NameCallback ? this.getPlayer2NameCallback() : 'Green');
                    const winnerTotalCaptures = winnerColor === 'red' ? (16 - this.greenPiecesCount) : (16 - this.redPiecesCount);
                    if (this.showWinPopupCallback) {
                        this.showWinPopupCallback(winnerName, winnerTotalCaptures);
                    } else {
                        alert(`${this.currentPlayer.toUpperCase()} has no moves. ${winnerName} wins!`);
                    }
                }, 10);
                return true; 
            }
        }
        return false; 
    },
    
    getPossibleMoves: function(sourcePointData, forCaptureOnly) {
        const moves = [];
        if (!sourcePointData || typeof sourcePointData.id !== 'number') return moves; 
        const sourceId = sourcePointData.id;
        const actualCaptureOnly = !!forCaptureOnly; 

        this.adj.get(sourceId)?.forEach(neighborId => {
            const neighborPointData = this.getPointDataById(neighborId);
            if (!neighborPointData) return;

            if (!neighborPointData.type && !actualCaptureOnly) { 
                moves.push({ targetPointData: neighborPointData, isCapture: false, capturedPointData: null });
            }
            else if (this.isOpponentPiece(neighborPointData)) {
                const dx = neighborPointData.x - sourcePointData.x;
                const dy = neighborPointData.y - sourcePointData.y;
                const beyondX = neighborPointData.x + dx;
                const beyondY = neighborPointData.y + dy;

                const beyondPointData = this.pointCoordinates.find(p => Math.abs(p.x - beyondX) < 0.1 && Math.abs(p.y - beyondY) < 0.1);

                if (beyondPointData && !beyondPointData.type && this.adj.get(neighborId)?.includes(beyondPointData.id)) {
                    moves.push({ targetPointData: beyondPointData, isCapture: true, capturedPointData: neighborPointData });
                }
            }
        });
        return moves;
    },

    updateTurnIndicator: function() {
        // This function might need access to DOM elements outside the board container.
        // For now, assuming they are globally accessible by ID.
        const player1Indicator = document.getElementById('player1-turn-indicator');
        const player2Indicator = document.getElementById('player2-turn-indicator');
        const statusDisplay = document.querySelector('.status'); 

        if (player1Indicator && player2Indicator) {
            if (this.currentPlayer === 'red') {
                player1Indicator.classList.add('active');
                player2Indicator.classList.remove('active');
                if (statusDisplay) statusDisplay.textContent = 'Current turn: Red';
            } else {
                player2Indicator.classList.add('active');
                player1Indicator.classList.remove('active');
                if (statusDisplay) statusDisplay.textContent = 'Current turn: Green';
            }
        } else {
            // console.warn('Turn indicators (player1-turn-indicator/player2-turn-indicator) not found in the DOM.');
        }

        let generalIndicator = document.getElementById('turn-indicator'); 
        if (generalIndicator) {
             generalIndicator.textContent = `Current turn: ${this.currentPlayer === 'red' ? 'Red' : 'Green'}`;
        }
    },

    updateMustCaptureIndicator: function() {
        let indicator = document.getElementById('must-capture-indicator');
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'must-capture-indicator';
            indicator.style.position = 'absolute';
            indicator.style.top = '10px';
            indicator.style.left = '50%';
            indicator.style.transform = 'translateX(-50%)';
            indicator.style.padding = '5px 10px';
            indicator.style.backgroundColor = 'rgba(255, 0, 0, 0.7)';
            indicator.style.color = 'white';
            indicator.style.borderRadius = '5px';
            indicator.style.zIndex = '100';
            // Assuming 'boardElementsContainer' is the main game board container or body
            const gameArea = this.boardElementsContainer || document.body;
            gameArea.appendChild(indicator);
        }
        // সর্বদাই ইন্ডিকেটর হাইড করে দিন যেহেতু ক্যাপচার বাধ্যতামূলক নয়
        indicator.style.display = 'none';
        indicator.textContent = ''; // টেক্সট খালি করে দিন
    },

    getAllValidMovesForPlayer: function(playerColor) {
        const allPossibleMoves = [];
        const captureOnly = false;

        // চাল সংগ্রহ করুন
        for (const piece of this.pointCoordinates) {
            if (piece.type && piece.type.startsWith(playerColor)) {
                // যদি জাম্প বাধ্যতামূলক হয়, তাহলে শুধুমাত্র জাম্প চাল বিবেচনা করুন
                const movesForThisPiece = this.getPossibleMoves(piece, false);
                
                movesForThisPiece.forEach(move => {
                    // যদি জাম্প বাধ্যতামূলক হয় এবং এটি জাম্প না হয়, তবে উপেক্ষা করুন

                    allPossibleMoves.push({
                        fromId: piece.id,
                        toId: move.targetPointData.id,
                        type: move.isCapture ? 'jump' : 'move',
                        capturedId: move.isCapture && move.capturedPointData ? move.capturedPointData.id : null,
                        // ডিবাগিং বা কম্পিউটার প্লেয়ারের সরাসরি ব্যবহারের জন্য সহায়ক ডেটা
                        fromPoint: piece, // ComputerPlayer এ সরাসরি ব্যবহারের জন্য পুরো অবজেক্ট
                        targetPoint: move.targetPointData,
                        isCapture: move.isCapture,
                        capturedPoint: move.capturedPointData
                    });
                });
            }
        }
        return allPossibleMoves;
    },

    makeComputerMove: function() {
        if (this.gameOver || !this.isComputerMode || this.currentPlayer !== this.computerPlayerColor) {
            return;
        }
        this.processingComputerMove = true;
        // console.log(`কম্পিউটার (${this.computerPlayerColor}) ভাবছে...`);

        let availableMoves;
        if (this.consecutiveCapture && this.selectedPiece) {
            const pieceForConsecutiveJump = this.getPointDataById(this.selectedPiece.id);
            if (!pieceForConsecutiveJump) { // যদি কোনো কারণে পিস না পাওয়া যায়
                console.error("Computer: Selected piece for consecutive jump not found.");
                this.consecutiveCapture = false;
                this.selectedPiece = null;
                this.processingComputerMove = false;
                this.switchPlayer();
                return;
            }
            availableMoves = this.getPossibleMoves(pieceForConsecutiveJump, true) // শুধুমাত্র জাম্প
                .filter(m => m.isCapture)
                .map(move => ({
                    fromId: pieceForConsecutiveJump.id,
                    toId: move.targetPointData.id,
                    type: 'jump',
                    capturedId: move.capturedPointData ? move.capturedPointData.id : null,
                    fromPoint: pieceForConsecutiveJump,
                    targetPoint: move.targetPointData,
                    isCapture: true,
                    capturedPoint: move.capturedPointData
                }));
            
            if (availableMoves.length === 0) {
                // console.log("কম্পিউটার: নির্বাচিত পিস দিয়ে আর কোনো ধারাবাহিক জাম্প নেই।");
                this.consecutiveCapture = false;
                this.selectedPiece = null;
                this.processingComputerMove = false;
                this.switchPlayer();
                return;
            }
        } else {
            availableMoves = this.getAllValidMovesForPlayer(this.computerPlayerColor);
        }

        if (availableMoves.length === 0) {
            // console.log("কম্পিউটারের কোনো চাল উপলব্ধ নেই।");
            this.processingComputerMove = false;
            // checkNoValidMoves এটি পরিচালনা করবে, তাই এখানে switchPlayer() কল করার দরকার নেই
            return;
        }

        const chosenMoveData = this.computerPlayerInstance.makeMove(this.pointCoordinates, availableMoves);

        if (chosenMoveData) {
            // console.log("কম্পিউটার এই চালটি বেছে নিয়েছে:", chosenMoveData);
            setTimeout(() => {
                const fromPoint = this.getPointDataById(chosenMoveData.fromId);
                const toPoint = this.getPointDataById(chosenMoveData.toId);
                let capturedPoint = null;
                if (chosenMoveData.isCapture && chosenMoveData.capturedId !== null) {
                    capturedPoint = this.getPointDataById(chosenMoveData.capturedId);
                }

                if (!fromPoint || !toPoint || (chosenMoveData.isCapture && chosenMoveData.capturedId !== null && !capturedPoint)) {
                    console.error("Computer move error: invalid point data for selected move.", chosenMoveData);
                    this.processingComputerMove = false;
                    this.switchPlayer(); // প্লেয়ার পরিবর্তন করে পুনরুদ্ধারের চেষ্টা করুন
                    return;
                }
                
                this.selectedPiece = fromPoint; // দৃশ্যত পিস নির্বাচন করুন
                this.renderBoard(); // নির্বাচন দেখান

                setTimeout(() => { // চাল দেওয়ার আগে নির্বাচনের জন্য ছোট বিলম্ব
                    const gameEndedByThisMove = this.movePiece(fromPoint, toPoint, chosenMoveData.isCapture, capturedPoint);
                    this.renderBoard(); // চালের পরে বোর্ড আপডেট করুন

                    if (gameEndedByThisMove) {
                        this.gameOver = true; // movePiece দ্বারা খেলা শেষ হলে gameOver সেট করুন
                        this.processingComputerMove = false;
                        return; // খেলা শেষ, আর কোনো পদক্ষেপ নেই
                    }

                    if (chosenMoveData.isCapture) {
                        const pieceAtNewLocation = this.getPointDataById(toPoint.id);
                        const furtherCaptures = this.getPossibleMoves(pieceAtNewLocation, true).filter(m => m.isCapture);
                        if (furtherCaptures.length > 0) {
                            // console.log("Computer has another jump.");
                            this.selectedPiece = pieceAtNewLocation; // যে পিসটি এইমাত্র চাল দিয়েছে এবং ক্যাপচার করেছে
                            this.consecutiveCapture = true;
                            this.makeComputerMove(); // পরবর্তী জাম্পের জন্য পুনরাবৃত্ত কল
                        } else {
                            this.consecutiveCapture = false;
                            this.selectedPiece = null;
                            this.processingComputerMove = false;
                            this.switchPlayer();
                        }
                    } else {
                        this.consecutiveCapture = false;
                        this.selectedPiece = null;
                        this.processingComputerMove = false;
                        this.switchPlayer();
                    }
                }, 300); // চালের জন্য বিলম্ব
            }, 700); // "ভাবনার" জন্য প্রাথমিক বিলম্ব
        } else {
            // console.log("Computer could not choose a move (returned null).");
            this.processingComputerMove = false;
            this.switchPlayer(); // অথবা checkNoValidMoves এটি পরিচালনা করবে
        }
    },

    // Add other game logic methods here as needed
    // Ensure this is the last part of GameLogic object before the closing };
    // For example, if there were other methods, they would be here.
    // If updateMustCaptureIndicator was the very last one, this structure is fine.

    initOnline: function(boardElementsContainer, db, rCode, localPName, p1Name, p2Name, updateScoreCb, showWinPopupCb) {
        console.log("GameLogic.initOnline called with:", { rCode, localPName, p1Name, p2Name });
        this.boardElementsContainer = boardElementsContainer;
        if (!this.boardElementsContainer) {
            console.error("Board elements container not found for GameLogic.initOnline!");
            return;
        }

        this.database = db;
        this.roomCode = rCode;
        this.localPlayerName = localPName;
        this.player1Name = p1Name; 
        this.player2Name = p2Name; 
        this.currentMode = 'online'; // Set the current mode to online

        // Determine local player's color based on their name
        if (this.localPlayerName === this.player1Name) {
            this.localPlayerColor = 'red'; // Player 1 is always 'red'
        } else if (this.localPlayerName === this.player2Name) {
            this.localPlayerColor = 'green'; // Player 2 is always 'green'
        } else {
            console.error("Local player name does not match player1 or player2 name.");
            this.localPlayerColor = null; // Should not happen
        }

        this.updateScoreCallback = updateScoreCb; 
        this.showWinPopupCallback = showWinPopupCb; 

        this.getPlayer1NameCallback = () => this.player1Name;
        this.getPlayer2NameCallback = () => this.player2Name;

        this.gameOver = false;
        this.processingComputerMove = false; 
        this.isComputerMode = false; 
        this.computerPlayerInstance = null;
        this.selectedPiece = null;
        this.mustCapture = false;
        this.consecutiveCapture = false;
        this.redPiecesCount = 16;
        this.greenPiecesCount = 16;
        this.scores = { player1: 0, player2: 0 };

        // Initialize the board with the correct perspective
        this.initializeBoardAndLogic();

        // Set up Firebase listeners for online mode
        if (this.database && this.roomCode) {
            this.setupOnlineGameListeners();
        }
    },

    setupOnlineGameListeners: function() {
        const roomRef = this.database.ref('rooms/' + this.roomCode);

        if (this.firebaseListenersAttached && this.onlineGameStateListener) {
            console.log("Detaching previous Firebase listener for room: ", this.roomCode);
            roomRef.off('value', this.onlineGameStateListener);
            this.firebaseListenersAttached = false;
        }
        
        this.onlineGameStateListener = roomRef.on('value', snapshot => {
            if (!snapshot.exists()) {
                console.warn(`Room ${this.roomCode} does not exist anymore.`);
                if (this.onlineGameStateListener) roomRef.off('value', this.onlineGameStateListener);
                this.firebaseListenersAttached = false;
                return;
            }
            const roomData = snapshot.val();
            console.log("GameLogic received roomData update:", roomData);

            if (roomData.status === 'waiting' || roomData.status === 'waiting_for_rematch') {
                console.log("Game status is waiting/rematch. GameLogic will not re-initialize board here.");
                this.gameOver = true;
                return;
            }

            if (roomData.status === 'playing') {
                this.gameOver = roomData.gameOver || false;
                this.currentPlayer = roomData.turn || 'red'; 
                this.scores = roomData.scores ? { ...roomData.scores } : { player1: 0, player2: 0 };
                this.redPiecesCount = roomData.redPiecesCount !== undefined ? roomData.redPiecesCount : 16;
                this.greenPiecesCount = roomData.greenPiecesCount !== undefined ? roomData.greenPiecesCount : 16;
                this.mustCapture = roomData.mustCapture || false;
                this.consecutiveCapture = roomData.consecutiveCapture || false;
                
                if(this.consecutiveCapture && roomData.selectedPieceIdForConsecutiveCapture){
                    this.selectedPiece = this.getPointDataById(roomData.selectedPieceIdForConsecutiveCapture);
                } else if (!this.consecutiveCapture) {
                    this.selectedPiece = null;
                }

                if (roomData.board) {
                    const newPointCoordinates = roomData.board.map(pInfo => {
                        const pointElement = this.boardElementsContainer.querySelector(`.point[data-point-id="${pInfo.id}"]`);
                        return { ...pInfo, element: pointElement };
                    });
                    
                    if (JSON.stringify(this.pointCoordinates.map(p=>({id:p.id, type:p.type}))) !== JSON.stringify(newPointCoordinates.map(p=>({id:p.id, type:p.type})))) {
                        this.pointCoordinates = newPointCoordinates;
                        if (this.adj.size === 0 || !this.areAllElementsPresent()) {
                            this.rebuildAdjacencyListAndElements();
                        }
                    }
                } else {
                    if (this.localPlayerName === this.player1Name) {
                        console.log("Host: Initializing and pushing board state to Firebase.");
                        this.initializeBoardAndLogic(true);
                        const initialBoardStateForFirebase = this.pointCoordinates.map(p => ({ id: p.id, x: p.x, y: p.y, type: p.type }));
                        roomRef.update({
                            board: initialBoardStateForFirebase,
                            turn: this.currentPlayer,
                            scores: this.scores,
                            redPiecesCount: this.redPiecesCount,
                            greenPiecesCount: this.greenPiecesCount,
                            gameOver: this.gameOver,
                            mustCapture: this.checkForAnyCapture(this.currentPlayer)
                        });
                    } else {
                        console.log("Client: Waiting for host to initialize board state.");
                        return;
                    }
                }
                this.renderBoard();
                if (this.updateScoreCallback) this.updateScoreCallback();
                
                if (this.gameOver && roomData.winner) {
                    if (this.showWinPopupCallback) {
                        const winnerTotalCaptures = roomData.winner === this.player1Name ? this.scores.player1 : this.scores.player2;
                        this.showWinPopupCallback(roomData.winner, winnerTotalCaptures);
                    }
                } else if (!this.gameOver){
                    this.checkNoValidMoves();
                }
            }
        }, error => {
            console.error("Error listening to room game state:", error);
        });
        this.firebaseListenersAttached = true;
        console.log("GameLogic.initOnline finished setup. Firebase listener attached for room: ", this.roomCode);
    },

    areAllElementsPresent: function() {
        if (!this.pointCoordinates || this.pointCoordinates.length === 0) return false;
        return this.pointCoordinates.every(p => p.element);
    },

    rebuildAdjacencyListAndElements: function() {
        // Ensure pointCoordinates has IDs and types, then create/update elements
        // This is crucial if boardRenderer.drawBoard() was called before GameLogic had full point data
        if (typeof BoardRenderer !== 'undefined' && typeof BoardRenderer.createPoint === 'function') {
            this.pointCoordinates.forEach(pInfo => {
                if (!pInfo.element) { // If element is missing, try to create it
                    const existingElement = this.boardElementsContainer.querySelector(`.point[data-point-id="${pInfo.id}"]`);
                    if (existingElement) {
                        pInfo.element = existingElement;
                    } else {
                        // This assumes BoardRenderer's createPoint can be called to add missing points
                        // It might be better for BoardRenderer.drawBoard to handle this based on GameLogic.pointCoordinates
                        // For now, let's log if elements are missing, full re-render might be needed by BoardRenderer
                        console.warn(`Point element for ID ${pInfo.id} missing during rebuild. BoardRenderer.drawBoard should create it.`);
                    }
                }
            });
        }
        this.adj.clear();
        this.pointCoordinates.forEach(p => this.adj.set(p.id, []));
        this.rebuildAdjacencyList(); // Call the existing rebuildAdjacencyList logic
    },

    rebuildAdjacencyList: function() {
        const pointIndexToId = (xIdx, yIdx) => {
            const targetX = this.gridX[xIdx]; 
            const targetY = this.gridY[yIdx];
            const found = this.pointCoordinates.find(p => Math.abs(p.x - targetX) < 0.01 && Math.abs(p.y - targetY) < 0.01);
            return found ? found.id : -1;
        };

        const connections = [];
        connections.push([[0,0],[2,0]], [[2,0],[4,0]]);
        connections.push([[1,1],[2,1]], [[2,1],[3,1]]);
        connections.push([[0,2],[1,2]], [[1,2],[2,2]], [[2,2],[3,2]], [[3,2],[4,2]]);
        connections.push([[0,3],[1,3]], [[1,3],[2,3]], [[2,3],[3,3]], [[3,3],[4,3]]);
        connections.push([[0,4],[1,4]], [[1,4],[2,4]], [[2,4],[3,4]], [[3,4],[4,4]]);
        connections.push([[0,5],[1,5]], [[1,5],[2,5]], [[2,5],[3,5]], [[3,5],[4,5]]);
        connections.push([[0,6],[1,6]], [[1,6],[2,6]], [[2,6],[3,6]], [[3,6],[4,6]]);
        connections.push([[1,7],[2,7]], [[2,7],[3,7]]);
        connections.push([[0,8],[2,8]], [[2,8],[4,8]]);
        connections.push([[2,0],[2,1]], [[2,1],[2,2]], [[2,2],[2,3]], [[2,3],[2,4]], [[2,4],[2,5]], [[2,5],[2,6]], [[2,6],[2,7]], [[2,7],[2,8]]);
        connections.push([[0,2],[0,3]], [[0,3],[0,4]], [[0,4],[0,5]], [[0,5],[0,6]]);
        connections.push([[1,2],[1,3]], [[1,3],[1,4]], [[1,4],[1,5]], [[1,5],[1,6]]);
        connections.push([[3,2],[3,3]], [[3,3],[3,4]], [[3,4],[3,5]], [[3,5],[3,6]]);
        connections.push([[4,2],[4,3]], [[4,3],[4,4]], [[4,4],[4,5]], [[4,5],[4,6]]);
        connections.push( [[0,2],[1,3]], [[1,3],[2,4]], [[2,4],[3,5]], [[3,5],[4,6]] );
        connections.push( [[0,6],[1,5]], [[1,5],[2,4]], [[2,4],[3,3]], [[3,3],[4,2]] );
        connections.push( [[0,0],[1,1]], [[1,1],[2,2]], [[2,2],[3,3]], [[3,3],[4,4]] );
        connections.push( [[0,8],[1,7]], [[1,7],[2,6]], [[2,6],[3,5]], [[3,5],[4,4]] );
        connections.push( [[4,8],[3,7]], [[3,7],[2,6]], [[2,6],[1,5]], [[1,5],[0,4]] );
        connections.push( [[0,4],[1,3]], [[1,3],[2,2]], [[2,2],[3,1]], [[3,1],[4,0]] );

        this.adj.forEach((value, key) => this.adj.set(key, [])); // Clear existing connections before rebuilding

        connections.forEach(conn => {
            const p1_indices = conn[0];
            const p2_indices = conn[1];
            const id1 = pointIndexToId(p1_indices[0], p1_indices[1]);
            const id2 = pointIndexToId(p2_indices[0], p2_indices[1]);

            if (id1 !== -1 && id2 !== -1) {
                if (this.adj.has(id1)) this.adj.get(id1).push(id2);
                if (this.adj.has(id2)) this.adj.get(id2).push(id1);
            } else {
                // console.warn("Could not find points for connection:", p1_indices, p2_indices);
            }
        });
        // console.log("Adjacency list rebuilt.", this.adj);
    },

    initializeBoardAndLogic: function(isOnlineInitialSetup = false) {
        this.pointCoordinates.length = 0;
        this.adj.clear();
        
        if (!this.database || isOnlineInitialSetup) { // Offline mode or host's initial online setup
            if (this.isComputerMode) { // This block is for offline computer mode
                this.currentPlayer = Math.random() < 0.5 ? 'red' : 'green'; 
            } else if (!this.isComputerMode && !this.database) { // Pure offline 2-player
                this.currentPlayer = Math.random() < 0.5 ? 'red' : 'green';
            } else if (isOnlineInitialSetup) { // Host setting up online game
                this.currentPlayer = 'red'; // Host (P1) is red, red starts
            }
        } // In online mode (not initial setup), currentPlayer comes from Firebase

        this.selectedPiece = null;
        this.mustCapture = false; 
        this.consecutiveCapture = false;
        this.redPiecesCount = 16;
        this.greenPiecesCount = 16;
        this.scores = { player1: 0, player2: 0 };
        this.gameOver = false;

        const initialLayoutWithIds = this.getInitialLayout(); 

        initialLayoutWithIds.forEach(pInfo => {
            const pointElement = this.boardElementsContainer.querySelector(`.point[data-point-id="${pInfo.id}"]`);
            this.pointCoordinates.push({ ...pInfo, element: pointElement });
            this.adj.set(pInfo.id, []);
        });
        
        this.rebuildAdjacencyList(); 

        if (!this.database || isOnlineInitialSetup) { // Render only for offline or host's initial setup
             this.renderBoard(); 
             if(!this.database) this.checkNoValidMoves(); // For offline, check moves after initial render
        }
        if (isOnlineInitialSetup) {
            this.mustCapture = this.checkForAnyCapture(this.currentPlayer);
        }
    },

    handlePointClick: function(clickedDivElement) {
        const clickedPointIdInitial = parseInt(clickedDivElement?.dataset?.pointId, 10);
        const clickedPointDataInitial = this.getPointDataById(clickedPointIdInitial);

        if (clickedPointDataInitial && clickedPointDataInitial.type !== '' && !this.isCurrentPlayerPiece(clickedPointDataInitial) && !this.selectedPiece) {
            return;
        }

        if (this.gameOver) {
            return;
        }

        if (this.database && this.localPlayerColor && this.localPlayerColor !== this.currentPlayer) {
            return;
        }

        if (this.isComputerMode && this.currentPlayer === this.computerPlayerColor) {
            if (this.processingComputerMove) {
                return;
            }
            return;
        }

        if (!clickedDivElement || !clickedDivElement.dataset || !clickedDivElement.dataset.pointId) return;
        const clickedPointId = parseInt(clickedDivElement.dataset.pointId, 10);
        const clickedPointData = this.getPointDataById(clickedPointId);
        if (!clickedPointData) return;

        if (this.selectedPiece) {
            const validMoves = this.getPossibleMoves(this.selectedPiece, this.mustCapture || this.consecutiveCapture);
            const move = validMoves.find(m => m.targetPointData.id === clickedPointData.id);

            if (move) {
                const gameOver = this.movePiece(this.selectedPiece, clickedPointData, move.isCapture, move.capturedPointData);
                if (gameOver) return;

                let moveSuccessful = false;
                if (move.isCapture) {
                    const furtherCaptures = this.getPossibleMoves(clickedPointData, true).filter(m => m.isCapture);
                    if (furtherCaptures.length > 0) {
                        this.selectedPiece = clickedPointData;
                        this.consecutiveCapture = true;
                        this.renderBoard();
                        this.syncOnlineState();
                        clearTimeout(this.captureTimeoutId);
                        this.captureTimeoutId = setTimeout(() => {
                            if (this.consecutiveCapture) {
                                this.consecutiveCapture = false;
                                this.switchPlayer();
                            }
                        }, 3000);
                    } else {
                        clearTimeout(this.captureTimeoutId);
                        this.consecutiveCapture = false;
                        this.switchPlayer();
                    }
                    moveSuccessful = true;
                } else {
                    clearTimeout(this.captureTimeoutId);
                    this.consecutiveCapture = false;
                    this.switchPlayer();
                    moveSuccessful = true;
                }
            } else if (clickedPointData.id === this.selectedPiece.id) {
                this.deselectPiece();
            } else if (this.isCurrentPlayerPiece(clickedPointData) && !this.consecutiveCapture) {
                this.selectPiece(clickedPointData);
            } else {
                this.deselectPiece();
            }
        } else if (this.isCurrentPlayerPiece(clickedPointData) && !this.consecutiveCapture) {
            this.selectPiece(clickedPointData);
        }
    },

    checkForAnyCapture: function(playerColor) {
        return false; 
    },

    checkNoValidMoves: function() {
        if (this.gameOver) return true; // If already over, no need to check

        let canMove = false;
        const currentMustCapture = this.database ? this.mustCapture : this.checkForAnyCapture(this.currentPlayer);

        for (const pData of this.pointCoordinates) {
            if (this.isCurrentPlayerPiece(pData)) {
                const moves = this.getPossibleMoves(pData, currentMustCapture || this.consecutiveCapture); 
                if (moves.length > 0) {
                    canMove = true;
                    break;
                }
            }
        }

        if (!canMove) {
            if (this.redPiecesCount > 0 && this.greenPiecesCount > 0) { 
                // this.gameOver = true; // Set by caller (handlePointClick) or by Firebase update
                const gameActuallyOver = true; // Local flag for this check

                if (!this.database) { // Offline: show popup directly
                    this.renderBoard();
                    setTimeout(() => {
                        const winnerColor = this.currentPlayer === 'red' ? 'green' : 'red'; 
                        const winnerName = winnerColor === 'red' ? (this.getPlayer1NameCallback ? this.getPlayer1NameCallback() : 'Red') : (this.getPlayer2NameCallback ? this.getPlayer2NameCallback() : 'Green');
                        const winnerTotalCaptures = winnerColor === 'red' ? this.scores.player1 : this.scores.player2;
                        if (this.showWinPopupCallback) {
                            this.showWinPopupCallback(winnerName, winnerTotalCaptures);
                        }
                    }, 10);
                } else {
                    // Online: Firebase listener will handle UI update based on gameOver & winner fields.
                    // The calling function (handlePointClick) should have already set gameOver and winner in Firebase.
                    // This function's role here is mainly to confirm the no-move state.
                    console.log("Online: No valid moves for", this.currentPlayer, ". Game should be over.");
                }
                return gameActuallyOver; 
            }
        }
        return false; 
    }
};
