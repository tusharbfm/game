// computerPlayer.js

class ComputerPlayer {
    constructor(playerNumber) {
        this.playerNumber = playerNumber;
        // TODO: Add more advanced logic for the computer
    }

    makeMove(boardState, availableMoves) {
        // The boardState parameter is not used in this simple logic, but kept for future improvements.
        if (!availableMoves || availableMoves.length === 0) {
            console.log("No available moves for computer.");
            return null;
        }

        // জাম্প চালগুলোকে অগ্রাধিকার দিন
        const jumpMoves = availableMoves.filter(move => move.type === 'jump');
        if (jumpMoves.length > 0) {
            // যদি জাম্প চাল উপলব্ধ থাকে, তাহলে একটি এলোমেলো জাম্প চাল বেছে নিন
            const randomIndex = Math.floor(Math.random() * jumpMoves.length);
            const selectedMove = jumpMoves[randomIndex];
            console.log(`Computer (player ${this.playerNumber}) chose a jump:`, selectedMove);
            return selectedMove;
        }

        // যদি কোনো জাম্প চাল না থাকে, তাহলে একটি এলোমেলো সাধারণ চাল বেছে নিন
        const normalMoves = availableMoves.filter(move => move.type === 'move');
        if (normalMoves.length > 0) {
            const randomIndex = Math.floor(Math.random() * normalMoves.length);
            const selectedMove = normalMoves[randomIndex];
            console.log(`Computer (player ${this.playerNumber}) chose a normal move:`, selectedMove);
            return selectedMove;
        } else {
            // এটি তখনই ঘটবে যদি শুধুমাত্র জাম্প চাল উপলব্ধ থাকে কিন্তু কোনো কারণে ফিল্টার না হয়
            // অথবা যদি কোনো সাধারণ চালও না থাকে (যা availableMoves.length === 0 দ্বারা ধরা উচিত ছিল)
            console.log("No normal move found for computer even though moves were available. Unexpected state.");
            // ফলব্যাক হিসেবে প্রথম উপলব্ধ চালটি রিটার্ন করুন
            const selectedMove = availableMoves[0];
            console.log(`Computer (player ${this.playerNumber}) chose first available move as fallback:`, selectedMove);
            return selectedMove;
        }
    }
}

// ComputerPlayer ক্লাসটিকে এক্সপোর্ট করুন যাতে অন্যান্য ফাইলে এটি ব্যবহার করা যায়
// যদি আপনি মডিউল ব্যবহার করেন (যেমন ES6 মডিউল), তাহলে নিচের লাইনটি ব্যবহার করুন:
// export default ComputerPlayer;

// যদি আপনি মডিউল ব্যবহার না করেন, তাহলে এটি গ্লোবাল স্কোপে থাকবে
// অথবা আপনি এটিকে একটি গ্লোবাল অবজেক্টের সাথে সংযুক্ত করতে পারেন, যেমন:
// window.ComputerPlayer = ComputerPlayer;
